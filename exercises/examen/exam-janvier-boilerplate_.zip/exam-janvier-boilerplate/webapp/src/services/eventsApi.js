
const retrieveAll = () => {
}

const create = (newVolume) => {
}

const remove = (resourceId) => {
}


export {
    retrieveAll,
    create,
    remove
}