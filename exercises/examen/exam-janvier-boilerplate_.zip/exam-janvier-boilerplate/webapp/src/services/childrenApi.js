const retrieveAll = () => {
    
}


export {
    retrieveAll
}