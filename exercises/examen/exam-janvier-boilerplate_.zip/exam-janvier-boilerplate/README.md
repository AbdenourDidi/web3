# Boilerplate application examen web3

## Base de données

L'API à besoin d'une base de données contenant 2 collections : `children` et `events`.
Pour cela, utilisez MongoBD Atlas.
Un fichier db.json est disponible avec des données de test.

## Front/Back

Un fichier README.md est disponible dans chaque projet. Lisez-le attentivement avant de commencer.